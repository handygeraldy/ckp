

<?php $__env->startSection('container'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0"><?php echo e($title); ?></h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item text-gray-800">CKP</li>
            <li class="breadcrumb-item text-gray-800">Arsip</li>
        </ol>
    </div>

    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col text-right">
                            <span>
                                <a href="<?php echo e(route('arsip.filter', ['tahun' => $prev_year, 'bulan' => $prev_month])); ?>"><i
                                        class="fa-solid fa-caret-left"></i></a>
                                <?php echo e(getMonth($bulan) . ' ' . $tahun); ?>

                                <a href="<?php echo e(route('arsip.filter', ['tahun' => $next_year, 'bulan' => $next_month])); ?>"><i
                                        class="fa-solid fa-caret-right"></i></a>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="tabel" class="table table-hover table-striped">
                            <thead>
                                <tr class="text-center align-middle">
                                    <th>No</th>
                                    <th style="min-width: 80px">Bulan</th>
                                    <th style="min-width: 200px">Nama Pegawai</th>
                                    <th>Nilai Kuantitas</th>
                                    <th>Nilai Kualitas</th>
                                    <th>Nilai Akhir</th>
                                    <th style="min-width: 150px"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($d->bulan . '-' . $d->tahun); ?></td>
                                        <td><?php echo e($d->user_name); ?></td>
                                        <td><?php echo e($d->avg_kuantitas); ?></td>
                                        <td><?php echo e($d->avg_kualitas); ?></td>
                                        <td><?php echo e($d->nilai_akhir); ?></td>
                                        <td style="min-width: 100px;">
                                            <div class="row">
                                                <a href="<?php echo e(route($route_ . '.tampil', $d->id)); ?>"
                                                    class="btn btn-primary btn-sm">
                                                    <i class="fa fa-eye"></i></a>
                                                <a href="<?php echo e(route('ckp.export', $d->id)); ?>"
                                                    class="btn btn-success btn-sm"><i class="fa fa-download"></i> Export</a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#tabel').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\ckp\resources\views/ckp/arsip/index.blade.php ENDPATH**/ ?>