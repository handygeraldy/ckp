
<link rel="stylesheet" href="<?php echo e(asset('/css/argon.css?v=1.2.0')); ?>" type="text/css">
<?php $__env->startSection('container'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0">Dashboard</h1>

    </div>
    <div class="text-right">
        <span>
            <a href="<?php echo e(route('index.ckp.filter', ['tahun' => $prev_year, 'bulan' => $prev_month])); ?>"><i
                    class="fa-solid fa-caret-left"></i></a>
            <?php echo e(getMonth($bulan) . ' ' . $tahun); ?>

            <a href="<?php echo e(route('index.ckp.filter', ['tahun' => $next_year, 'bulan' => $next_month])); ?>"><i
                    class="fa-solid fa-caret-right"></i></a>
        </span>
    </div>
    <div class="accordion" id="accordionEx">
        <div class="row">
            
            <div class="col-xl-3 col-md-6 mt-3">
                <div class="card">
                    <div class="card-header mb-0" id="headingOne">
                        <a data-toggle="collapse" data-target="#collapseOne" aria-expanded="true"
                            onclick="changeIcon(this)">
                            <p class="mb-0">
                                BELUM DIAJUKAN <i class="fas fa-plus float-right"></i>
                            </p>
                        </a>
                    </div>
                    <div class="card-body pt-0">
                        <div class="row">
                            <div class="col">
                                <span class="h2 font-weight-bold mb-0"><?php echo e($sum_status['0'] + $sum_status['1']); ?></span>
                            </div>
                            <div class="col-auto">
                                <div class="icon icon-shape bg-gradient-light text-white rounded-circle shadow">
                                    <i class="fa-solid fa-pen"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionEx">
                        <div class="card-body">
                            <table class="table table-borderless">
                                <tbody>
                                    <tr>
                                        <?php $__currentLoopData = $rekap_pegawai[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($p); ?></td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $rekap_pegawai[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($p); ?></td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6 mt-3">
                <div class="card">
                    <div class="card-header mb-0" id="headingTwo">
                        <a data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true"
                            onclick="changeIcon(this)">
                            <p class="mb-0">
                                DIPERIKSA KETUA TIM <i class="fas fa-plus float-right"></i>
                            </p>
                        </a>
                    </div>
                    <div class="card-body pt-0">
                        <div class="row">
                            <div class="col">
                                <span class="h2 font-weight-bold mb-0"><?php echo e($sum_status['2']); ?></span>
                            </div>
                            <div class="col-auto">
                                <div class="icon icon-shape bg-gradient-blue text-white rounded-circle shadow">
                                    <i class="fa-solid fa-file-pen"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionEx">
                        <div class="card-body">
                            <table class="table table-borderless">
                                <tbody>
                                    <tr>
                                        <?php $__currentLoopData = $rekap_pegawai[2]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($p); ?></td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-md-6 mt-3">
                <div class="card">
                    <div class="card-header mb-0" id="headingThree">
                        <a data-toggle="collapse" data-target="#collapseThree" aria-expanded="true"
                            onclick="changeIcon(this)">
                            <p class="mb-0">
                                DIPERIKSA DIREKTUR <i class="fas fa-plus float-right"></i>
                            </p>
                        </a>
                    </div>
                    <div class="card-body pt-0">
                        <div class="row">
                            <div class="col">
                                <span class="h2 font-weight-bold mb-0"><?php echo e($sum_status['3']); ?></span>
                            </div>
                            <div class="col-auto">
                                <div class="icon icon-shape bg-gradient-info text-white rounded-circle shadow">
                                    <i class="fa-solid fa-magnifying-glass"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionEx">
                        <div class="card-body">
                            <table class="table table-borderless">
                                <tbody>
                                    <tr>
                                        <?php $__currentLoopData = $rekap_pegawai[3]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($p); ?></td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-xl-3 col-md-6 mt-3">
                <div class="card">
                    <div class="card-header mb-0" id="headingFour">
                        <a data-toggle="collapse" data-target="#collapseFour" aria-expanded="true"
                            onclick="changeIcon(this)">
                            <p class="mb-0">
                                DISETUJUI <i class="fas fa-plus float-right"></i>
                            </p>
                        </a>
                    </div>
                    <div class="card-body pt-0">
                        <div class="row">
                            <div class="col">
                                <span class="h2 font-weight-bold mb-0"><?php echo e($sum_status['4']); ?></span>
                            </div>
                            <div class="col-auto">
                                <div class="icon icon-shape bg-gradient-success text-white rounded-circle shadow">
                                    <i class="fa-solid fa-clipboard-check"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionEx">
                        <div class="card-body">
                            <table class="table table-borderless">
                                <tbody>
                                    <tr>
                                        <?php $__currentLoopData = $rekap_pegawai[4]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($p); ?></td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div>
        
        
        
    </div>
    <script>
        function changeIcon(anchor) {
            var icon = anchor.querySelector("i");
            icon.classList.toggle('fa-plus');
            icon.classList.toggle('fa-minus');

            anchor.querySelector("span").textContent = icon.classList.contains('fa-plus') ? "Read more" : "Read less";
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\ckp\resources\views/ckp/dashboard.blade.php ENDPATH**/ ?>