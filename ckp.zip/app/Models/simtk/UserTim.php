<?php

namespace App\Models\simtk;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserTim extends Model
{
    use HasFactory;
    public $timestamps = false;
}
