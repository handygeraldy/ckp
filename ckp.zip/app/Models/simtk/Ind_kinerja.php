<?php

namespace App\Models\simtk;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ind_kinerja extends Model
{
    use HasFactory;
}
