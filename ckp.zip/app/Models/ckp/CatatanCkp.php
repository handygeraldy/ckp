<?php

namespace App\Models\ckp;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CatatanCkp extends Model
{
    
    protected $guarded = ['id'];

}
